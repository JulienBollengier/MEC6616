import numpy as np
from meshConnectivity import MeshConnectivity
from mod_classe import Mod


def polygon_area(vertices):
    """
    Calcule l'aire d'un polygone à partir de ses sommets.
    :param vertices: liste de tuples représentant les coordonnées (x, y) des sommets.
    :return: aire du polygone.
    """
    n = len(vertices)  # Nombre de sommets (3 pour triangle, 4 pour quadrilatère)
    area = 0.0

    # Appliquer la formule du polygone
    for i in range(n):
        x_i, y_i = vertices[i]
        x_next, y_next = vertices[(i + 1) % n]  # Le sommet suivant (avec bouclage sur le premier sommet)
        area += x_i * y_next - x_next * y_i

    return abs(area) / 2.0

def least_square(mesh_obj, bcdata, phi, phi_frontiere, q, dz):
        
        conec = MeshConnectivity(mesh_obj, verbose=False)
        conec.compute_connectivity()
        number_of_elements = mesh_obj.get_number_of_elements()
        face_to_nodes = mesh_obj.face_to_nodes
        mod = Mod(mesh_obj)
        
        # Matrices / Vecteurs
        ATA = np.zeros((number_of_elements, 2, 2))
        ATAI = np.zeros((number_of_elements, 2, 2))
        A_LS = np.zeros((2, 2))
        B = np.zeros((number_of_elements, 2))
              
        # Boundary faces
        for i_face in range(mesh_obj.get_number_of_boundary_faces()):
            tag = mesh_obj.get_boundary_face_to_tag(i_face)
            bc_type = bcdata[tag][0]
            # Mailles contenant l'arête
            elements = mesh_obj.get_face_to_elements(i_face)
  
            # Nœuds de l'arête
            nodes = face_to_nodes[i_face]
            # Coordonnées des 2 nœuds
            node_1 = np.array([mesh_obj.node_to_xcoord[nodes[0]], mesh_obj.node_to_ycoord[nodes[0]]])
            node_2 = np.array([mesh_obj.node_to_xcoord[nodes[1]], mesh_obj.node_to_ycoord[nodes[1]]])
            # Nœuds dans les 2 mailles
            nodes_element_1, nodes_element_2 = mod.nodes_dans_element(i_face)
            # Centre de gravité
            cg_1 = mod.centre_gravite(nodes_element_1)
            #vecteur de l'arete
            vector_face = node_2-node_1
            # distance entre les 2 nœuds
            coord_milieu_arete = (node_2 + node_1)/2.
            # Calcul dx dy
            dx = (coord_milieu_arete - cg_1)[0]
            dy = (coord_milieu_arete - cg_1)[1]
            
            # for i_element in range(elements[0]):
            #     print('élément', i_element)
            noeuds_element = mesh_obj.get_element_to_nodes(elements[0])
            """---------------------------------------------------------------------"""
            noeuds_element_gauche = mesh_obj.get_element_to_nodes(elements[0])
            noeuds_element_droite = mesh_obj.get_element_to_nodes(elements[1])
            #print('noeuds_element', noeuds_element)
            #     print('noeuds élément', i_element, noeuds_element)
                # Récupérer les coordonnées des nœuds de l'élément
            coords_gauche = []
            coords_droite = []
            for node_id in noeuds_element_gauche:
                x, y = mesh_obj.get_node_to_xycoord(node_id)
                coords_gauche.append((x, y))  # Ajouter les coordonnées (x, y) à la liste
                
            for node_id in noeuds_element_droite:
                x, y = mesh_obj.get_node_to_xycoord(node_id)
                coords_droite.append((x, y))  # Ajouter les coordonnées (x, y) à la liste
            
            # Calculer l'aire de l'élément (qu'il soit triangle ou quadrilatère)
            aire_gauche = polygon_area(coords_gauche)
            aire_droite = polygon_area(coords_droite)
           
            
            """---------------------------------------------------------------------"""
            
            if bc_type == 'DIRICHLET':
                B[elements[0], 0] += (coord_milieu_arete[0]-cg_1[0])*(phi_frontiere[i_face]-phi[elements[0]]) #+ q * aire_gauche * dz
                B[elements[0], 1] += (coord_milieu_arete[1]-cg_1[1])*(phi_frontiere[i_face]-phi[elements[0]]) #+ q * aire_gauche * dz
                A_LS[0, 0] = dx * dx
                A_LS[1, 0] = dx * dy
                A_LS[0, 1] = dy * dx
                A_LS[1, 1] = dy * dy
                
            if bc_type == 'NEUMANN':
                nodes = face_to_nodes[i_face]           #On récupère les noeuds qui composent l'arête
                
                x_noeud_1 = mesh_obj.get_node_to_xcoord(nodes[0])     #Coord x et y noeud 1 de l'arête i
                y_noeud_1 = mesh_obj.get_node_to_ycoord(nodes[0])   
            
                x_noeud_2 = mesh_obj.get_node_to_xcoord(nodes[1])     #Coord x et y noeud 2 de l'arête i
                y_noeud_2 = mesh_obj.get_node_to_ycoord(nodes[1])      
                
                milieu_gauche = mod.centre_gravite(nodes_element_1)
                milieu_droite = np.array([x_noeud_2 + x_noeud_1,y_noeud_2 + y_noeud_1])/2.

                dx = (milieu_droite- milieu_gauche)[0]
                dy = (milieu_droite- milieu_gauche)[1]
                
                vector_face = np.array([x_noeud_2-x_noeud_1,y_noeud_2-y_noeud_1])
                normale = mod.normale(vector_face)
                
                delta_x = (dx * normale[0] + dy * normale[1]) *normale[0]
                delta_y = (dx * normale[0] + dy * normale[1]) *normale[1]
                
                an_tg_x = (dx*normale[0] + dy*normale[1])*normale[0]
                an_tg_y = (dx*normale[0] + dy*normale[1])*normale[1]
                
                B[elements[0], 0] += an_tg_x*(dx*normale[0] + dy*normale[1])*phi_frontiere[i_face] #+ q * aire_gauche * dz
                B[elements[0], 1] += an_tg_y*(dx*normale[0] + dy*normale[1])*phi_frontiere[i_face] #+ q * aire_gauche * dz
                
                A_LS[0, 0] = delta_x * delta_x
                A_LS[1, 0] = delta_x * delta_y
                A_LS[0, 1] = delta_y * delta_x
                A_LS[1, 1] = delta_y * delta_y
            ATA[elements[0]] += A_LS

        # Internal faces
        for i_face in range(mesh_obj.get_number_of_boundary_faces(), mesh_obj.get_number_of_faces()):
            elements = mesh_obj.get_face_to_elements(i_face)
            #print('elements', elements[0])
            # Mailles contenant l'arête
            elements_voisins = mesh_obj.get_face_to_elements(i_face)
            # Nœuds de l'arête
            nodes = face_to_nodes[i_face]
            # Coordonnées des 2 nœuds
            node_1 = np.array([mesh_obj.node_to_xcoord[nodes[0]], mesh_obj.node_to_ycoord[nodes[0]]])
            node_2 = np.array([mesh_obj.node_to_xcoord[nodes[1]], mesh_obj.node_to_ycoord[nodes[1]]])
            # Nœuds dans les 2 mailles
            nodes_element_1, nodes_element_2 = mod.nodes_dans_element(i_face)
            # Centres de gravité
            cg_1 = mod.centre_gravite(nodes_element_1)
            cg_2 = mod.centre_gravite(nodes_element_2)
            # Calcul dx dy
            delta_x = cg_2[0]-cg_1[0]
            delta_y = cg_2[1]-cg_1[1]
            
            """---------------------------------------------------------------------"""
            noeuds_element_gauche = mesh_obj.get_element_to_nodes(elements[0])
            noeuds_element_droite = mesh_obj.get_element_to_nodes(elements[1])
            #print('noeuds_element', noeuds_element)
            #     print('noeuds élément', i_element, noeuds_element)
                # Récupérer les coordonnées des nœuds de l'élément
            coords_gauche = []
            coords_droite = []
            for node_id in noeuds_element_gauche:
                x, y = mesh_obj.get_node_to_xycoord(node_id)
                coords_gauche.append((x, y))  # Ajouter les coordonnées (x, y) à la liste
                
            for node_id in noeuds_element_droite:
                x, y = mesh_obj.get_node_to_xycoord(node_id)
                coords_droite.append((x, y))  # Ajouter les coordonnées (x, y) à la liste
            
            # Calculer l'aire de l'élément (qu'il soit triangle ou quadrilatère)
            aire_gauche = polygon_area(coords_gauche)
            aire_droite = polygon_area(coords_droite)
    
           
            """---------------------------------------------------------------------"""
            
            A_LS[0, 0] = delta_x * delta_x
            A_LS[1, 0] = delta_x * delta_y
            A_LS[0, 1] = delta_y * delta_x
            A_LS[1, 1] = delta_y * delta_y
            ATA[elements_voisins[0]] += A_LS
            ATA[elements_voisins[1]] += A_LS

            B[elements_voisins[0], 0] += delta_x*(phi[elements_voisins[1]]-phi[elements_voisins[0]]) #+ q*aire_gauche * dz
            B[elements_voisins[0], 1] += delta_y*(phi[elements_voisins[1]]-phi[elements_voisins[0]]) #+ q*aire_gauche * dz
            B[elements_voisins[1], 0] += delta_x*(phi[elements_voisins[1]]-phi[elements_voisins[0]]) #- q*aire_droite * dz
            B[elements_voisins[1], 1] += delta_y*(phi[elements_voisins[1]]-phi[elements_voisins[0]]) #- q*aire_droite * dz
 
        ATAI = np.linalg.inv(ATA)
        GRAD = np.einsum('...ij,...j', ATAI, B)
        return GRAD
    
"""    
def centre_element(mesh_obj, i_element):    
    nodes = mesh_obj.get_element_to_nodes(i_element)    #On récupère les indices des noeuds de l'élément
    
    x_center, y_center = 0.0, 0.0   #Coordonnées du centre
    
    # 3. Parcourir les noeuds et additionner leurs coordonnées
    for i_node in nodes:
        x_center += mesh_obj.get_node_to_xcoord(i_node)
        y_center += mesh_obj.get_node_to_ycoord(i_node)
    
    # 4. Diviser par le nombre de noeuds pour obtenir la moyenne (point milieu)
    n_nodes = len(nodes)
    x_center /= n_nodes
    y_center /= n_nodes
    
    # 5. Retourner les coordonnées du point milieu
    return x_center, y_center
"""