# -*- coding: utf-8 -*-
"""
Created on Mon Sep 30 16:19:28 2024

@author: tiboe
"""

import numpy as np
import time
from meshGenerator import MeshGenerator
from meshConnectivity import MeshConnectivity
from meshPlotter import MeshPlotter
from mod_classe import Mod
import fonctions as fonctions
import Least_Square as ls

# Paramètres du problème
gamma = 0.5  # Conductivité thermique (W/m.K)
L = 0.02  # Longueur du rectangle (m)
TA = 100  # Température en A (°C)
TB = 200  # Température en B (°C)
q = 1000  # Terme source (kW/m³)
lc = 0.004  # Longueur caractéristique
nombre_iteration = 20
dz = 1  # Distance pour le terme source

# Génération du maillage
mesher = MeshGenerator()
mesh_parameters = {'mesh_type': 'TRI', 'lc': lc}
mesh_obj = mesher.rectangle([0.0, L, 0.0, L], mesh_parameters)

# Conditions aux limites
bcdata = (['DIRICHLET', 0], ['NEUMANN', 1], ['DIRICHLET', 2], ['NEUMANN', 3])

# Connexion du maillage
conec = MeshConnectivity(mesh_obj)
conec.compute_connectivity()

# Initialisation des matrices
number_of_elements = mesh_obj.get_number_of_elements()
A = np.zeros((number_of_elements, number_of_elements), dtype=float)
B = np.zeros(number_of_elements, dtype=float)
phi = np.zeros(number_of_elements, dtype=float)

# Initialisation des températures à la frontière
mod = Mod(mesh_obj)
phi_frontiere = np.zeros(mesh_obj.get_number_of_boundary_faces(), dtype=float)  # Initialiser phi_frontiere
phi_frontiere = fonctions.initialisation(mesh_obj, mod, bcdata, TA, TB, L, phi_frontiere, q, gamma, dz)

    # On initialise les matrices/vecteurs à 0 partout
GRAD = np.zeros((number_of_elements,2), dtype=float)     
A = np.zeros((number_of_elements, number_of_elements), dtype=float)
B = np.zeros(number_of_elements, dtype=float)
phi = np.zeros(number_of_elements, dtype=float)
phi_frontiere = np.zeros(mesh_obj.get_number_of_boundary_faces(), dtype=float)
source = np.zeros(number_of_elements)
    
# Initialisation phi à la frontière
phi_frontiere = fonctions.initialisation(mesh_obj, mod, bcdata, TA, TB, L, phi_frontiere, q, gamma, dz)

for i in range(nombre_iteration) :
    A = np.zeros((number_of_elements, number_of_elements), dtype=float)
    B = np.zeros(number_of_elements, dtype=float)
    source = np.zeros(number_of_elements)
        
    # Boundary faces
    for i_face_front in range(mesh_obj.get_number_of_boundary_faces()):
        A, B = fonctions.boundary(mesh_obj, mod, i_face_front, bcdata, gamma, TA, TB, L, A, B, phi_frontiere, q, dz)
    # Internal faces
    for i_face_interne in range(mesh_obj.get_number_of_boundary_faces(), mesh_obj.get_number_of_faces()):
        A, B = fonctions.interne(mesh_obj, mod, i_face_interne, gamma, A, B, GRAD, q, dz)
            
    # Ajout du terme source
    for i_element in range(number_of_elements):
            start = mesh_obj.element_to_nodes_start[i_element]
            end = mesh_obj.element_to_nodes_start[i_element+1]
            nodes = mesh_obj.element_to_nodes[start:end]
            # print(nodes)
            source[i_element] = q*np.abs(mod.aire_element(nodes))
            # print(nodes)
            # print("aire",np.abs(mod.aire_element(nodes)))
            # print(q*np.abs(mod.aire_element(nodes)))
            B[i_element] += source[i_element]
            
    phi = np.linalg.solve(A, B)
    # print("\nmax diff phi-phi2",np.max(np.abs(phi2-phi)))
    # phi = phi2
    GRAD = ls.least_square(mesh_obj, bcdata, phi, phi_frontiere, q, dz)


    # Résoudre le système linéaire
    try:
        phi = np.linalg.solve(A, B)
    except np.linalg.LinAlgError:
        print("Matrice A singulière. Vérification des valeurs de A et B :")
        print("Matrice A :")
        print(A)
        print("Vecteur B :")
        print(B)
        break  # Sortir de la boucle si la matrice est singulière

# Fonction pour la solution analytique
def solution_analytique(x, L, TA, TB, q, k):
    return ((TB - TA) / L + q / (2 * k) * (L - x)) * x + TA

# Comparaison de la solution numérique avec la solution analytique
x_values = np.linspace(0, L, number_of_elements)
analytical_solution = solution_analytique(x_values, L, TA, TB, q, gamma)

# Calcul de l'erreur
error = np.abs(phi - analytical_solution)
error_norm = np.linalg.norm(error)

print(f"Erreur L2: {error_norm}")

# Analyse du temps de calcul
# Temps pour matrice dense
start_time = time.time()
phi_dense = np.linalg.solve(A, B)
dense_time = time.time() - start_time

# Temps pour matrice creuse
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import spsolve

A_sparse = csr_matrix(A)
start_time = time.time()
phi_sparse = spsolve(A_sparse, B)
sparse_time = time.time() - start_time

print(f"Temps pour matrice dense: {dense_time:.4f} s")
print(f"Temps pour matrice creuse: {sparse_time:.4f} s")

# Visualisation des résultats
plotter = MeshPlotter()
plotter.plot_mesh(mesh_obj, label_points=True, label_elements=True, label_faces=True)

# Optionnel : afficher les solutions
import matplotlib.pyplot as plt

plt.figure()
plt.plot(x_values, phi, label='Solution Numérique', marker='o')
plt.plot(x_values, analytical_solution, label='Solution Analytique', linestyle='--')
plt.xlabel('Position (m)')
plt.ylabel('Température (°C)')
plt.title('Comparaison des Solutions Numérique et Analytique')
plt.legend()
plt.grid()
plt.show()

