import numpy as np
from meshGenerator import MeshGenerator
from meshConnectivity import MeshConnectivity
from meshPlotter import MeshPlotter
from mod_classe import Mod
import Least_Square as ls
import fonctions as fonctions

# def coupe(mesh_obj, mod, parametre, element):
#     start = mesh_obj.element_to_nodes_start[element]
#     end = mesh_obj.element_to_nodes_start[element+1]
#     nodes = mesh_obj.element_to_nodes[start:end]
#     centre_gravite = mod.centre_gravite(nodes)
#     return abs(parametre[0]*centre_gravite[0]+parametre[1]*centre_gravite[1]+parametre[2])/np.sqrt(parametre[0]**2 + parametre[1]**2)

if __name__ == "__main__":
    
    gamma = 0.5 #W/m.K
    L = 0.02 #0.02 #m
    ymax = L
    TA = 100
    TB = 200
    lc = 0.004 #0.01
    tolerance = lc / 4
    # TA = 373.15    #Température en A EN KELVIN
    # TB = 473.15    #Température en B EN KELVIN
    nombre_iteration = 20
    dz = 1
    q = 1e6 #1000000.
    mesher = MeshGenerator()
    
    mesh_parameters = {'mesh_type': 'TRI', 'lc': lc}
    # mesh_parameters = {'mesh_type': 'QUAD',
    #                     'Nx': 5,
    #                     'Ny': 5
    #                     }
    mesh_obj = mesher.rectangle([0.0, L, 0.0, ymax], mesh_parameters)

    # Conditions aux limites
    bcdata = (['DIRICHLET', 0], ['NEUMANN', 1], ['DIRICHLET', 2], ['NEUMANN', 3])

    conec = MeshConnectivity(mesh_obj, verbose=False)
    conec.compute_connectivity()

    number_of_elements = mesh_obj.get_number_of_elements()
    face_to_nodes = mesh_obj.face_to_nodes

    plotter = MeshPlotter()
    plotter.plot_mesh(mesh_obj, label_points=True, label_elements=True, label_faces=True)

    mod = Mod(mesh_obj) 
    
    # On initialise les matrices/vecteurs à 0 partout
    GRAD = np.zeros((number_of_elements,2), dtype=float)     
    A = np.zeros((number_of_elements, number_of_elements), dtype=float)
    B = np.zeros(number_of_elements, dtype=float)
    phi = np.zeros(number_of_elements, dtype=float)
    phi_frontiere = np.zeros(mesh_obj.get_number_of_boundary_faces(), dtype=float)
    source = np.zeros(number_of_elements)
    
    # Initialisation phi à la frontière
    phi_frontiere = fonctions.initialisation(mesh_obj, mod, bcdata, TA, TB, L, phi_frontiere, q, gamma, dz)

    for i in range(nombre_iteration) :
        A = np.zeros((number_of_elements, number_of_elements), dtype=float)
        B = np.zeros(number_of_elements, dtype=float)
        source = np.zeros(number_of_elements)
        
        # Boundary faces
        for i_face_front in range(mesh_obj.get_number_of_boundary_faces()):
            A, B = fonctions.boundary(mesh_obj, mod, i_face_front, bcdata, gamma, TA, TB, L, A, B, phi_frontiere, q, dz)
        # Internal faces
        for i_face_interne in range(mesh_obj.get_number_of_boundary_faces(), mesh_obj.get_number_of_faces()):
            A, B = fonctions.interne(mesh_obj, mod, i_face_interne, gamma, A, B, GRAD, q, dz)
            
         # Ajout du terme source
        for i_element in range(number_of_elements):
            start = mesh_obj.element_to_nodes_start[i_element]
            end = mesh_obj.element_to_nodes_start[i_element+1]
            nodes = mesh_obj.element_to_nodes[start:end]
            # print(nodes)
            source[i_element] = q*np.abs(mod.aire_element(nodes))
            # print(nodes)
            # print("aire",np.abs(mod.aire_element(nodes)))
            # print(q*np.abs(mod.aire_element(nodes)))
            B[i_element] += source[i_element]
            
        phi = np.linalg.solve(A, B)
        # print("\nmax diff phi-phi2",np.max(np.abs(phi2-phi)))
        # phi = phi2
        GRAD = ls.least_square(mesh_obj, bcdata, phi, phi_frontiere, q, dz)

