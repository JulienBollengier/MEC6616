import numpy as np


def phi_CL(x, y , TA, TB, L, q, gamma):  
    return ((TB-TA)/L + q*(L-x)/(2*gamma))*x + TA

def d_phi_CL(x, y, TA, TB, L, q, gamma):
    return np.array([(TB-TA)/L + (q*L)/(2*gamma) - (x*q)/gamma, 0.])

def polygon_area(vertices):
    """
    Calcule l'aire d'un polygone à partir de ses sommets.
    :param vertices: liste de tuples représentant les coordonnées (x, y) des sommets.
    :return: aire du polygone.
    """
    n = len(vertices)  # Nombre de sommets (3 pour triangle, 4 pour quadrilatère)
    area = 0.0

    # Appliquer la formule du polygone
    for i in range(n):
        x_i, y_i = vertices[i]
        x_next, y_next = vertices[(i + 1) % n]  # Le sommet suivant (avec bouclage sur le premier sommet)
        area += x_i * y_next - x_next * y_i
    return abs(area) / 2.0

def initialisation(mesh_obj, mod, bcdata, TA, TB, L, phi_frontiere, q, gamma, dz):
    face_to_nodes = mesh_obj.face_to_nodes
    
    for i_face in range(mesh_obj.get_number_of_boundary_faces()):
        tag = mesh_obj.get_boundary_face_to_tag(i_face)
        bc_type = bcdata[tag][0]
        nodes = face_to_nodes[i_face]
        # Coordonnées des 2 nœuds
        node_1 = np.array([mesh_obj.node_to_xcoord[nodes[0]], mesh_obj.node_to_ycoord[nodes[0]]])
        node_2 = np.array([mesh_obj.node_to_xcoord[nodes[1]], mesh_obj.node_to_ycoord[nodes[1]]])
        coord_milieu_arete = (node_2 + node_1)/2.
        
        if bc_type == 'DIRICHLET':
            phi_frontiere[i_face] = phi_CL(coord_milieu_arete[0], coord_milieu_arete[1], TA, TB, L, q, gamma)
        elif bc_type == 'NEUMANN':
            vector_face = node_2-node_1
            normal = mod.normale(vector_face)
            grad_phi = d_phi_CL(coord_milieu_arete[0], coord_milieu_arete[1], TA, TB, L, q ,gamma)
            phi_frontiere[i_face] = np.dot(grad_phi,normal)
    return phi_frontiere

def boundary(mesh_obj, mod, i_face, bcdata, gamma, TA, TB, L, A, B, phi_frontiere, q, dz):
    elements = mesh_obj.get_face_to_elements(i_face)    #on récupère les éléments gauche/droite de l'arête
    tag = mesh_obj.get_boundary_face_to_tag(i_face)
    face_to_nodes = mesh_obj.face_to_nodes  #on récupère les noeuds des arêtes dans l'ordre

    bc_type = bcdata[tag][0]
    nodes = face_to_nodes[i_face]   #noeud de l'arête i
    nodes_element_1, nodes_element_2 = mod.nodes_dans_element(i_face)
    
    """---------------------------------------------------------------------"""
    noeuds_element_gauche = mesh_obj.get_element_to_nodes(elements[0])
    #noeuds_element_droite = mesh_obj.get_element_to_nodes(elements[1]) #existe pas au frontière

        # Récupérer les coordonnées des nœuds de l'élément
    coords_gauche = []
    #coords_droite = []
    for node_g in noeuds_element_gauche:
        x, y = mesh_obj.get_node_to_xycoord(node_g)
        coords_gauche.append((x, y))  # Ajouter les coordonnées (x, y) à la liste
    
    # Calculer l'aire de l'élément (qu'il soit triangle ou quadrilatère)
    aire_gauche = polygon_area(coords_gauche)
    
    """---------------------------------------------------------------------"""
    
    # Coordonnées des 2 nœuds
    point_a = np.array([mesh_obj.node_to_xcoord[nodes[0]], mesh_obj.node_to_ycoord[nodes[0]]])
    point_b = np.array([mesh_obj.node_to_xcoord[nodes[1]], mesh_obj.node_to_ycoord[nodes[1]]])

    normal = mod.normale(point_b-point_a)
    
    point_P = mod.centre_gravite(nodes_element_1)
    
    point_milieu_arete = (point_b + point_a)/2. 
    
    d_eta = np.linalg.norm(point_a-point_b)
    e_eta = (point_b-point_a)/d_eta
    
    d_ksi = np.linalg.norm(point_milieu_arete-point_P)
    e_ksi = (point_milieu_arete-point_P)/d_ksi
    
    proj_n_ksi = np.dot(normal, e_ksi)
    proj_ksi_eta = np.dot(e_ksi, e_eta)
    
    if bc_type == 'DIRICHLET':
        D = (gamma*d_eta)/(proj_n_ksi*d_ksi)
        phi_a = phi_CL(point_a[0], point_a[1], TA, TB, L, q, gamma)
        phi_b = phi_CL(point_b[0], point_b[1], TA, TB, L,q, gamma)       
        SD = -(gamma*proj_ksi_eta*d_eta*(phi_b-phi_a))/(d_eta*proj_n_ksi)
        print('SD frontière', SD)
        A[elements[0],elements[0]] += D
        B[elements[0]] += SD + D*phi_frontiere[i_face] #+ q * aire_gauche * dz
    elif bc_type == 'NEUMANN':
        grad_phi = 0 #d_phi_CL(point_milieu_arete[0], point_milieu_arete[1], TA, TB, L, q, gamma)
        B[elements[0]] += gamma*grad_phi*d_eta #+ q * aire_gauche * dz

    return A, B

def interne(mesh_obj, mod, i_face, gamma, A, B, GRAD, q, dz):
    elements = mesh_obj.get_face_to_elements(i_face)

    face_to_nodes = mesh_obj.face_to_nodes
    nodes = face_to_nodes[i_face]
    
    point_a = np.array([mesh_obj.node_to_xcoord[nodes[0]], mesh_obj.node_to_ycoord[nodes[0]]])
    point_b = np.array([mesh_obj.node_to_xcoord[nodes[1]], mesh_obj.node_to_ycoord[nodes[1]]])
    nodes_element_1, nodes_element_2 = mod.nodes_dans_element(i_face)

    """---------------------------------------------------------------------"""
    noeuds_element_gauche = mesh_obj.get_element_to_nodes(elements[0])
    noeuds_element_droite = mesh_obj.get_element_to_nodes(elements[1])

    coords_gauche = []
    coords_droite = []
    for node_id in noeuds_element_gauche:
        x, y = mesh_obj.get_node_to_xycoord(node_id)
        coords_gauche.append((x, y))  # Ajouter les coordonnées (x, y) à la liste
        
    for node_id in noeuds_element_droite:
        x, y = mesh_obj.get_node_to_xycoord(node_id)
        coords_droite.append((x, y))  # Ajouter les coordonnées (x, y) à la liste
    
    # Calculer l'aire de l'élément (qu'il soit triangle ou quadrilatère)
    aire_gauche = polygon_area(coords_gauche)
    aire_droite = polygon_area(coords_droite)

    """---------------------------------------------------------------------"""
    # Centres de gravité
    point_P = mod.centre_gravite(nodes_element_1)
    point_A = mod.centre_gravite(nodes_element_2)
   
    d_ksi = np.linalg.norm(point_A-point_P)   
    d_eta = np.linalg.norm(point_a-point_b)

    normal = mod.normale(point_b-point_a)    
    
    e_ksi = (point_A-point_P)/d_ksi  
    e_eta = (point_b-point_a)/d_eta
    
    proj_ksi_eta = np.dot(e_ksi, e_eta)
    proj_n_ksi = np.dot(normal, e_ksi)  
    
    D = (gamma*d_eta)/(d_ksi*proj_n_ksi)
        
    moyenne_grad = (GRAD[elements[0]]+GRAD[elements[1]])/2.
    
    SD = -gamma*(proj_ksi_eta/proj_n_ksi)*np.dot(moyenne_grad, e_eta)*d_eta   
    
    print('SD intern', SD)
    A[elements[0],elements[0]] += D
    A[elements[1],elements[1]] += D
    A[elements[0],elements[1]] += -D
    A[elements[1],elements[0]] += -D

    B[elements[0]] += SD #+ q * aire_gauche * dz
    B[elements[1]] += -SD #- q * aire_droite * dz
    return A, B