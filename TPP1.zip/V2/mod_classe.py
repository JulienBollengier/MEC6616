import numpy as np

from meshGenerator import MeshGenerator
class Mod():

    
    def __init__(self, mesh_obj : MeshGenerator() ):
        self.mesh_obj = mesh_obj


    def coordonnees(self, node):
        return np.array([self.mesh_obj.node_to_xcoord[node], self.mesh_obj.node_to_ycoord[node]])

    def distance(self,nodes):
        node_1 = self.coordonnees(nodes[0])
        node_2 = self.coordonnees(nodes[1])
        return np.linalg.norm(node_1-node_2)


    def nodes_dans_element(self,i_face):
        start = self.mesh_obj.element_to_nodes_start[self.mesh_obj.get_face_to_elements(i_face)]
        end = self.mesh_obj.element_to_nodes_start[self.mesh_obj.get_face_to_elements(i_face)+1]
        return self.mesh_obj.element_to_nodes[start[0]:end[0]], self.mesh_obj.element_to_nodes[start[1]:end[1]]


    def centre_gravite(self,nodes_element):
        c = self.coordonnees(nodes_element)
        return np.mean(c, axis=1)


    def normale(self,vecteur):
        # Rotation de 90° dans le sens horaire et normalisation du vecteur
        return np.array([vecteur[1], -vecteur[0]])/np.linalg.norm(vecteur)


    def aire_element(self,nodes_element):
        c = self.coordonnees(nodes_element)
        aire = 0.
        for i in range(c.shape[1]-1):
            aire += c[0, i]*c[1, i+1]-c[0, i+1]*c[1, i]
        return aire/2.
    